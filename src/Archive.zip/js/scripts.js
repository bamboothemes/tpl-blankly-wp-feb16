jQuery(document).ready(function($) {
	 	
	 		 	 	
});