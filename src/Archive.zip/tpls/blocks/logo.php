<?php defined('ZEN_ALLOW') or die();

/* =====================================================================
Template:	Xero - Base theme for the Zen Grid Framework v4.
Author: 	Anthony Olsen Joomlabamboo
Version: 	1.0
Created: 	August 2014
Copyright:	Anthony Olsen - (C) 2014 - All rights reserved
/* ===================================================================== */


?>
	<section id="logowrap" class="clearfix <?php echo $this->rowClass('logo');?>" role="banner">
		<div class="zen-container">
			<?php $this->getModules('logo');?>			
		</div>
	</section>