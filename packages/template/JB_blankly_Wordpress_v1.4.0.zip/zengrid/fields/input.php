<?php
/**
* @package   Zen Grid Framework
* @author    Joomlabamboo http://www.Jjoomlabamboo.com
* @copyright Copyright (C) Joomlabamboo
* @license   http://www.gnu.org/licenses/gpl.html GNU/GPL
*/

// No Direct Access
defined('_JEXEC') or die(); 

?>



<label class="<?php echo $class;?>">
	<?php echo $label;?>
</label>

<input class="<?php echo $class;?> uk-form uk-form-large uk-form-width-large" id="<?php echo $name;?>" data-compile="<?php echo $compile;?>" value="<?php echo $value;?>"/>
