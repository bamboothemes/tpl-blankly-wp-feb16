<?php
/**
* @package   Zen Grid Framework
* @author    Joomlabamboo http://www.Jjoomlabamboo.com
* @copyright Copyright (C) Joomlabamboo
* @license   http://www.gnu.org/licenses/gpl.html GNU/GPL
*/

// No Direct Access
defined('_JEXEC') or die(); 


// Define template name
if (!defined('TEMPLATE')) {
	define( 'TEMPLATE', basename(dirname(dirname(dirname(__FILE__)))));
}

// Template Path
$template_path = TEMPLATE_PATH;
$layoutpath		= TEMPLATE_PATH.'/settings/layouts/';


// Instantiate $zgf
$zgf = new zen();
$templateId = $zgf->template_id();

$files = JFolder::files($layoutpath,'', false, false );

// Read settings
$settings = $zgf->getsettings($templateId);

$current_layout = $settings->params->layout_preset;


$options ='';


foreach ($files as $key => $layout)
{
	
	$file = str_replace('.json', '', $layout);
	
	if($layout !=="index.html" && $layout !=="positions.json") {
	
		$options .= '<option value="'.$file.'"';
		if($file == $current_layout) {
			$options .= 'selected';
		}
		$options .= '>'.$file.'</option>';
	}
}	?>

<div id="layout-preset-wrap" style="float: left;width:45%;">
	<select id="layout_preset">
		<?php echo $options;?>
	</select>

	<a href="#none" class="uk-button-primary uk-button" id="apply-layout">Load Layout</a>
</div>

<input class="uk-form uk-form-large exclude advanced" id="layout-name" value="New Layout">
<a href="#" class="uk-button-primary uk-button exclude advanced" id="save-layout">Save Layout</a>

<div class="clearfix"></div>
<p class="info not-advanced">Click the show advanced options button above to be able to view advanced layout options.</p>
<?php 
// Get Theme Settings
$theme_layout = $zgf->getsettings($templateId);
$used_items = $theme_layout->layout;


// Compare keys with default layout with used layouts
if(file_exists(TEMPLATE_PATH . 'custom/positions.json')) {
	$default_layout = $zgf->get_json('custom/positions.json');
} else {
	$default_layout = $zgf->get_json('settings/layouts/positions.json');
}



echo '<div id="resize-container" class="advanced">';


foreach ($default_layout as $key => $row) { 
	
	if($key !=="main") {
		echo '<div id="'.$key.'" data-row="'.$key.'" class="module-row">';
		echo '<div class="row-title"><span>'.$key.'</span>'.
		'<div class="stack-position">'.
		'<div><span class="icon-desktop"></span>'.
		'<a class="stack-positions" id="hidden-desktop" href="#">Hide</a></div>'. 
		'<div><span class="icon-tablet"></span>'.
		'<a class="stack-positions" id="stack-tablets" href="#">Stack</a>'.
		'<a class="stack-positions" id="hidden-tablets" href="#">Hide</a>'.
		'<a class="stack-positions" id="no-change-tablets" href="#">No Change</a></div>'.
		'<div><span class="icon-mobile"></span>'.
		'<a href="#" class="stack-positions" id="stack-phones">Stack</a>'.
		'<a href="#" class="stack-positions" id="hidden-phones">Hide</a>'.
		'<a class="stack-positions" id="no-change-phones" href="#">No Change</a>'.
		'</div></div></div>';
		
		foreach ($row as $title => $width) {
			
			if(isset($used_items->$key->{'positions'}->{$title})) {
				$width = $used_items->$key->{'positions'}->{$title};
			}
			
			echo '<div id="'.$title.'" class="resizable ui-widget-content grid-'.$width.' visible" data-width="'.$width.'">';
			echo '<h3 class="ui-widget-header">';
			echo '<span class="icon-eye"></span>';
			echo '<span class="col-count"></span>'.ucfirst($title).' </h3>';
			echo '</div>';
			
		}
		
		echo '</div>';
	
		
		echo '<div data-id="'.$key.'" class="unused-modules"><span class="icon-eye cancel"></span>';
			
			foreach ($row as $title => $width) {
				echo '<div data-id="'.$title.'">'.ucfirst($title).'</div>';
			}
			
		echo '</div>';	
	}
	
	else {
		
		echo '<div id="'.$key.'" data-row="'.$key.'" class="module-row">';
			echo '<div class="row-title"><span>'.$key.'</span><a class="main-content-toggle" href="#main-left-right" id="maincontent_sidebar1_sidebar2">Main Left Right</a> / <a class="main-content-toggle" href="#left-main-right" id="sidebar1_maincontent_sidebar2">Left Main Right</a> / <a class="main-content-toggle" href="#left-right-main" id="sidebar1_sidebar2_maincontent">Left Right Main</a>'.
			'<div class="stack-position">'.
			'<div><span class="icon-desktop"></span>'.
			'<a class="stack-positions" id="hidden-desktop" href="#">Hide</a></div>'. 
			'<div><span class="icon-tablet"></span>'.
			'<a class="stack-positions" id="stack-tablets" href="#">Stack</a>'.
			'<a class="stack-positions" id="hidden-tablets" href="#">Hide</a>'.
			'<a class="stack-positions" id="no-change-tablets" href="#">No Change</a></div>'.
			'<div><span class="icon-mobile"></span>'.
			'<a href="#" class="stack-positions" id="stack-phones">Stack</a>'.
			'<a href="#" class="stack-positions" id="hidden-phones">Hide</a>'.
			'<a class="stack-positions" id="no-change-phones" href="#">No Change</a>'.
			'</div></div></div>';
			
				// Default main positions
				$default_main = (array)$default_layout->main;
				
				// Used positions
				$mainlayout = 	(array)$used_items->main->positions;
				
				// Get any iotems not used but should be in array
				// Items in this will be nulled and in the hidden row.
				$diff = array_diff_key($default_main,$mainlayout);
				
				
				foreach ($mainlayout as $title => $width) {
					echo '<div id="'.$title.'" class="resizable ui-widget-content grid-'.$width.' visible" data-width="'.$width.'">';
					echo '<h3 class="ui-widget-header">';
					echo '<span class="icon-eye"></span>';
					echo '<span class="col-count"></span>'.ucfirst($title).' </h3>';
					echo '</div>';
				}
				
				foreach ($diff as $title => $width) {
					echo '<div id="'.$title.'" class="resizable ui-widget-content grid-'.$width.' hidden" data-width="'.$width.'">';
					echo '<h3 class="ui-widget-header">';
					echo '<span class="icon-eye"></span>';
					echo '<span class="col-count"></span>'.ucfirst($title).' </h3>';
					echo '</div>';
				}
				
				
				
			echo '</div>';
			
			echo '<div data-id="'.$key.'" class="unused-modules"><span class="icon-eye cancel"></span>';
				
				foreach ($row as $title => $width) {
					echo '<div data-id="'.$title.'">'.ucfirst($title).'</div>';
				}
				
			echo '</div>';
			
	}
} ?>



<script>
	
	jQuery(document).ready(function($) {

		<?php // Loads the layout on first page laod
			foreach ($used_items as $key => $row) { 
	
			// Get state for classes
			$classes = $row->classes;
			$classes = explode(' ', $classes->classes);
			
			foreach ($classes as $class) {
				if($class!=="") { ?>
					$("#resize-container #<?php echo $key;?> #<?php echo $class;?>").addClass("active");
				<?php }
			}
			
			// Get positions
			$row = $row->positions;
			
			foreach ($row as $module => $item) { ?>
				$("#resize-container #<?php echo $module;?>").attr("data-active", "1");
			<?php } 
		} ?>
	});
</script>

</div>
	<script>
		
	jQuery(document).ready(function($) {
	
	// Sets the value of the save layout box with current layout 
	var layout = $('#layout_preset').val();
	
	// Set the save box with the current name
	$('#layout-name').val(layout);
	
	
	// Applies the layout
	$('#apply-layout').live('click', function() {
		
		$(document).set_layout_data('<?php echo TEMPLATE;?>');
		
		return false;
		
	});


	$('.main-content-toggle').live('click', function() {
		
		var main_layout = $(this).attr('id');
		main_layout = main_layout.split('_');
		
		// Remove existing unused blocks
		// So we can replace them with the current config.
		$('div[data-id="main"].unused-modules div').remove();
		
		$(main_layout).each(function(i, value) {
			
			var id = value;
			$('#main div.resizable').eq(i).attr('id', value);
			$('#main .ui-widget-header').eq(i).html('<span class="icon-eye"></span><span class="col-count">6</span>' + value);
			
			
			$('div[data-id="main"].unused-modules').append('<div data-id="' + value +'"">' + value +'</div>');
			
			if(!$('#' + value).hasClass('visible')) {
				$('div[data-id="main"].unused-modules [data-id="' + value + '"]').addClass('active').show();
			}
					
			
		});
		
		return false;
		
	});
	
});
</script>