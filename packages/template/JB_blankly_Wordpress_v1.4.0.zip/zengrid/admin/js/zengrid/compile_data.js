/*
Compile Data Function
 */

(function ($) {
		
	$.fn.compile_data = function (template, template_css) {
		
		// Establish variables
		var variables ="";

		// See if template.css is enabled in admin
		template_css= template_css || '0';
		
			
		// get all colour values from picker inputs
		$('.zt-picker').each(function() {
			
			// Get colour of picker
			var value = $(this).val();
				value = value.replace('#', '');
		
			// Get id of picker
			var id = $(this).attr('id'); 
			
			// Create delimited list of variables
			if(value !=="") {
				variables += id;
				variables += '||';
				variables += value;
				variables += '___';
			}
			
			// Set a default
			// In case value isnt set
			else {
			//	variables += id;
			//	variables += '||';
			//	variables += 'inherit';
			//	variables += '___';
			}  
		      		
		});
			
		// Get settings from other inputs marked to compile
		var settings = "";
		
		// Get all params that need to be sent through the compiler
		$('input[data-compile="1"],input[data-compile="both"],select[data-compile="both"],select[data-compile="1"]').each(function() {
			
			// Get the value
			var value = $(this).val();
			
			// Get the id
			var id = $(this).attr('id'); 
	
				// Created the delimited list
				settings += id;
				settings += '||';
				settings += value;
				settings += '___';
			    		
		});
	

		// Check for other settings
		// Using bootstrap or another framework
		var framework_enable = $('input#framework_enable').val();
		
		// Framework version we might be using
		var framework_version = $('#framework_version').val();
		
		// Which files are included
		var framework_files = $('li[data-name="framework_files_group"] input').val();
			framework_files = framework_files.slice(0,-1);
		
		// Is the output goign to be compressed
		var compress = $('li[data-name="compresscss"] input').val();
		
		// Do we use all FOnt Awesome files
		var fontawesome_type = $('#font_awesome_type').val();
		
		// are there any custom less files to add to the compiler
		var custom_less = $('#add_to_compiler').val();
		
		// Get the style being used
		var style_name = $('#save-style').val();
			style_name = style_name.replace(/\s+/g, '-').toLowerCase();
		
		// Set the saved value on click of the button
		$("#theme").val(style_name);
		
		// Any animations being used
		var animate = $('#enable_animations').val();
		
		// If animations
		if(animate) {
			
			var animations = "";
			
			// Loop through animation list to see which ones to include
			$('select[data-animate="1"]').each(function() {
				var animation = $(this).val();
				animations += animation;
				animations += ",";
			});
		}
		
		
		// Get rows styles
		var rowstyles = '';
		
		// Loop through row style settings to see what's being used
		$('[data-rowstyle="1"]').each(function() {
			
			var value = $(this).val();
			rowstyles += value;
			rowstyles += ','
		});
		
		
		// Create url variable for helper
		var url = '../index.php?template=' + template + '&tmpl=ajax&function=ajax-compiler';

		$.ajax({
	        url: url,
	        method: 'post',
	        context: document.body,
	        data: {
	        	settings: settings,
	        	variables: variables,
	        	compress: compress,
	        	framework_enable: framework_enable,
	        	framework_version: framework_version,
	        	framework_files: framework_files,
	        	fontawesome_type: fontawesome_type,
	        	custom_less: custom_less,
	        	style_name: style_name,
	        	animate: animate,
	        	animations: animations,
	        	template_css: template_css,
	        	rowstyles: rowstyles,
	        		admin:'1'
	        },
	        
	        beforeSend: function () {
	          	$('.compiler').addClass('active');
	          	
	          	$('.compiler .button-title').text('Compiling Less to CSS');
	          	
	          	$('#zgfmessage').html('<div class="alert alert-success"><h4 class="alert-heading">Message</h4><p>Compiling less to css and saving your changes ....</p></div>').fadeIn();
	          	            	                    
	        },
	        success: function (data) {
	        	$('.compiler').removeClass('active');
	        	jQuery('#zgfmessage').html(data).fadeIn('normal', function() {
	        			jQuery('#zgfmessage').delay(3000).fadeOut();
	        		});
	        	$('.compiler .button-title').text('Save and compile theme');
	        	var style_name = $('#save-style').val();
	        	
	        	$('input#theme').val(style_name);
	        	$('#compile_required').val('0');
	        }
	    });
	  
	};
		
})(jQuery);
