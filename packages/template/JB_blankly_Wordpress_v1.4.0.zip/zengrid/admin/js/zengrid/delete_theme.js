/*
colpick Color Picker
Copyright 2013 Jose Vargas. Licensed under GPL license. Based on Stefan Petre's Color Picker www.eyecon.ro, dual licensed under the MIT and GPL licenses

For usage and examples: colpick.com/plugin
 */

(function ($) {
		
	$.fn.delete_theme = function (template) {
			
		var theme = $('#cssfile').val();
		
		var url = '../index.php?template=' + template + '&tmpl=ajax&function=ajax-delete-theme';
	
		$.ajax({
	        url: url,
	        method: 'post',
	        context: document.body,
	        data: {
	        	theme:theme,
	        	admin:'1'
	        },
	        
	        beforeSend: function () {
	          	            	                    
	        },
	        success: function (data) {
	        	jQuery('#zgfmessage').html('<div class="alert alert-success"><h4 class="alert-heading">Message</h4><p>' + data +  'Less has been compiled to css.</p></div>').fadeIn('normal', function() {
	        			jQuery('#zgfmessage').delay(3000).fadeOut();
	        	});
	        	
	        	$("#cssfile option[value='"+ theme + "']").remove();
	        	
	        	var new_theme = $('#cssfile').val();
	        		new_theme = new_theme.replace('presets/theme.[example]-','');
	        	$('#save-style,#theme').val(new_theme);
	        	
	        }	
	    });
	  
	};
		
})(jQuery);
