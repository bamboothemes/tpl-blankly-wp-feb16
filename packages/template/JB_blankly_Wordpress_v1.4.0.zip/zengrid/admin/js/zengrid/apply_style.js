/*
colpick Color Picker
Copyright 2013 Jose Vargas. Licensed under GPL license. Based on Stefan Petre's Color Picker www.eyecon.ro, dual licensed under the MIT and GPL licenses

For usage and examples: colpick.com/plugin
 */

(function ($) {
		
	$.fn.apply_style = function (template,time) {
			
		var style = $('#style-preset').val();
		
		// Retrieve the appropriate json file	        	
		$.getJSON( '../templates/' + template + '/settings/config/'+ style + '.json?v=' + time, function( data ) {
			
			params = data['params'];
			
			// Parse through the json object and populate fields
			$.each( params, function( k, v ) {
				
				var $this = '#' + k;
			 	$($this).val(v);

			 	// Special case to populate the theme dropdown
			 	if(k == "theme") {
			 		$('#save-style').val(v);
			 		$('#cssfile,input#theme').val(v);
			 	
			 		$(document).set_theme_data(template);
			 	}
			 	
			 	if(k == "layout_preset") {
			 		$('#layout_preset,#layout-name').val(v);
			 		$(document).set_layout_data(template);
			 
			 	}
			 	     	     	
			 	
			 	// Color items
			 	if($($this).hasClass('zt-picker')) {
			 		
			 		$($this).css({'border-color': '#' + v})
			 		
			 		var firstletter = v.charAt(0);
			 		    			
						if(firstletter == "@") {
							
							var other = v.substring(1, v.length)
								other = $('input#' + other).val();
				
							$($this).css({'border-right-color': '#' +other});
						}
						
						
						var val = v;
						
						var firstletter = v.substring(0, 3);
							
							if(firstletter == "dar" || firstletter == "lig") {
								
								
								if(firstletter == "dar") {
									var other = val.substring(8, val.length);
									other = other.split(',');
								}
								
								
								if(firstletter == "lig") {
									var other = val.substring(9, val.length);
									other = other.split(',');
								}
								
								
								// Change % into a decimal    				
								var percentage = other[1].slice(0,-2);
									percentage = parseFloat(percentage) / 100.0;
									
									if(firstletter == "dar") {
										percentage = '-' + percentage;
									}
								
									
									other = other[0];
									other = $('input#' + other).val();
									
									var newColor = $(document).ColorLuminance(other, percentage); 
									
									$($this).css({'border-right-color': newColor});
							} 	     		    		
					}
			 	
			 	
			 	if($($this).is(':checkbox')) {
			 		
			 		var toggle = $($this).attr('id');
			 		
			 		// Set value to 0
			 		$($this).val('');
			 		
			 		// Check if checked and set to 1
			 		if(v == 1) {
			 			
			 			$('.' + toggle).fadeIn();
			 			$($this).prop('checked', 'true').val(1);
			 			
			 		}
			 		
			 		if(v == "" || v == 0) {
			 			$('.' + toggle).fadeOut();
			 			$($this).prop('checked', false).val(0);
			 			 
			 			
			 		}
			 		
			 	}
			 	
			 	if($($this).is('select')) {
			 	   	$($this + ' option[value="'+ v +'"]').attr("selected","selected");	
			 	  
			 	}
			 	
			 }); // End Params
			 
			 jQuery('#zgfmessage').html('<div class="alert alert-success"><p>New settings  have been applied to this template style.<br/> Please save your changes before proceeding.</p></div>').fadeIn('normal', function() {
			 			jQuery('#zgfmessage').delay(4000).fadeOut();
				});
			 		
			 		
			 $('#style-preset').val('none');
			
		});		
	}
		
})(jQuery);
