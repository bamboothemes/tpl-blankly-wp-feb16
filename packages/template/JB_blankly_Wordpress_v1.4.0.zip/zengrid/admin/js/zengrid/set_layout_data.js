/*
colpick Color Picker
Copyright 2013 Jose Vargas. Licensed under GPL license. Based on Stefan Petre's Color Picker www.eyecon.ro, dual licensed under the MIT and GPL licenses

For usage and examples: colpick.com/plugin
 */

(function ($) {
		
		// Load Layout Function
		$.fn.set_layout_data = function (template) {
	
			// Empty the resize container
			$('#resize-container').empty();
			
			// Get the layout to use
			layout = $('#layout_preset').val();
			
			// Set the save box with the current name
			$('#layout-name').val(layout);
			
			url = '../index.php?template=' + template + '&tmpl=ajax&function=ajax-layout&layout=' + layout;
					
			$.ajax({
			 	url: url,
			 	method: 'get',
			 	context: document.body,
			 	data: {
			 		admin:'1'
			 	},
			 	beforeSend: function () {
			   		    	            	                    
			 	},
			 
			 	success: function (data) {
			 		$('#resize-container').append(data);
			 		
			 		$( ".resizable" ).each(function() {
			 			var width = Math.round($(this).width() / 50);
			 			$(this).attr('class','').addClass('resizable ui-widget-content ui-resizable visible');
			 			$(this).find('.ui-widget-header span.col-count').text();
			 			$(this).find('.ui-widget-header span.col-count').text(width).parent().parent().addClass('grid-'+ width).attr('data-width', width);
			 			
			 			if($(this).attr('data-active')) {
			 				$(this).addClass('visible');
			 			} else {
			 				$(this).fadeOut().removeClass('visible');
			 				var id = $(this).attr('id');
			 				
			 				$('.unused-modules div[data-id="' + id + '"]').fadeIn().addClass('active').parent().addClass('active');
			 			}
			 		});
			 		
			 		
			 		$( ".resizable" ).resizable({
			 		      grid: 40,
			 		      minWidth:40,
			 		      containment: "#resize-container",
			 		      handles: 'e',
			 		      
			 		      resize: function( event, ui ) {
			 		      	$(this).attr('class','').addClass('resizable ui-widget-content ui-resizable visible');
			 		      	
			 		      	var width = Math.round($(this).width() / 50);
			 		      	$(this).find('.ui-widget-header span.col-count').text();
			 		      	$(this).find('.ui-widget-header span.col-count').text(width).parent().parent().addClass('grid-'+ width).attr('data-width', width);
			 		      	
			 		      }
			 		 });
			 	}
			});
		} 
		
		
})(jQuery);
