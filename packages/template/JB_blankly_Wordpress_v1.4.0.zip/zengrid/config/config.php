<?php
/**
 * @package		Zen Grid Framework v4, 1.4.1
 * @subpackage	Updated: February 22 2016
 * @author		Joomlabamboo http://www.joomlabamboo.com
 * @copyright 	Copyright (C) Joomlabamboo, February 22 2016
 * @license		http://www.gnu.org/licenses/gpl.html GNU General Public License version 2 or later;
 * @version		1.4.1
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

/**
 * Form Field class for the Joomla Framework.
 *
 * @package		ZGF4
 * @subpackage	Form
 * @since		1.6
 */

class JFormFieldConfig extends JFormField
{
	protected $type = 'Config';

	protected function getInput()
	{
		
		
		// Define template name
		if (!defined('TEMPLATE')) {
			define( 'TEMPLATE', basename(dirname(dirname(dirname(__FILE__)))));
		}
		
		// Include Zen Class
		if (!defined('TEMPLATE_PATH')) {
			define( 'TEMPLATE_PATH', JPATH_ROOT.'/templates/'.TEMPLATE.'/');
		}
		
		// Include Helpers
		include_once TEMPLATE_PATH.'/zengrid/helpers/helper.php'; 
	
		// Instantiate $zgf
		$zgf = new zen();
		
		// Config XML
		$config = $zgf->get_xml('settings/settings.xml');
		
		// Template Id
		$templateId = $zgf->template_id();
		
		// Read settings
		$settings = $zgf->getsettings($templateId);
		
		
		ob_start(); ?>
				<a id="top-page" name="top-page"></a>
		<div id="zgfmessage" class="message-box"></div>
		
		<div id="template-toolbar">
		
			<h3 class="inline-heading"><?php echo ucfirst(TEMPLATE);?> Template</h3>		
			
			<?php include(TEMPLATE_PATH.'/zengrid/fields/styles.php');?>
			
		</div>
		
		<div id="framework-options" class="basic">
			
			<div class="uk-grid">
			
			    <div id="zen-sidebar" class="uk-width-medium-1-5">
			       			       
			        <ul class="uk-nav" data-uk-tab="{connect:'#theme-settings'}">
			
			        		<?php // Sidebar Nav
			
			        			  foreach($config as $items) { 
			        			  
			        			  	$safename = strtolower(str_replace(' ', '-', $items['name']));?>
			        			  	
			        			  	<li id="<?php echo $safename; ?>" data-id="<?php echo $safename; ?>">
			
			        					<a name="<?php echo $safename; ?>" href="#<?php echo $safename; ?>"><span class="<?php echo $items['icon'];?>"></span><?php echo $items['name']; ?></a>
			
			        				</li>
			
			        		<?php }	?>
			
			        </ul>
			
			    </div>
			
			    <div class="uk-width-medium-5-5">
			    	
			        <ul id="theme-settings" class="uk-switcher">
			        <?php 	// Options container			
			        	
			        	foreach($config->children() as $fields) { 
			        	
			        	$safename = strtolower(str_replace(' ', '-', $fields['name']));
			        	
			        	?>
			        	
			        	<li id="<?php echo $safename; ?>">	
			        	
			        		<ul>	
			        	
			        			<?php //print_r($fields);
			        	
			        				foreach ($fields as $key => $field) { 
			        				
			        					$advanced = (string)$field['advanced'];
			        					
			        					
			        					?>
			        				
			        					
			        					<li data-display="<?php echo $field['display'];?>" data-name="<?php echo $field['name'];?>" <?php if($advanced) { ?>class="advanced"<?php } ?>>	
	        								<?php  
	        								
	        								
	        									$type = (string)$field['type'];
	        									$description = $field['description'];
	        									$label = $field['label'];
	        									$name = $field['name'];
	        									$class = $field['class'];
	        									$tag = $field['tag'];
	        									$compile = $field['compile'];
	        									$target = $field['target'];
	        									$folder = $field['folder'];
	        									$show_empty = $field['show_empty'];
	        									
	        									if(isset($settings->params->{$name})) {
	        										
	        										if($settings->params->{$name} !=="") {
	        											$value = $settings->params->{$name};
	        										}
	        										else {
	        											$value = $field['default'];
	        										}
	        									} else {
	        										$value = $field['default'];
	        									}
	        									
	        									// Get the layout preset used
	        									if($field['type'] == "layout") {
	        									//	$value = 'all_positions';
	        									}
	        									
	        									
	        									$options = array();
	        							
	        									foreach ($field->children() as $child) {
	        										$options[] = $child;
	        									}
	        								
	        									if(isset($type) && $type =="livepreview") {
	        									
	        										// Cant run the live preview field through the render
	        										// Because we want to use it to render fields
	        										// Watch out for the infinite loop
	        										
	        										include(TEMPLATE_PATH . 'zengrid/fields/livepreview.php');
	        										
	        									} else {
	        										
	        										// Determine the field typr and render the appropriate field
	        										echo $zgf->render($type,$description,$label,$options, $name,$class, $value, $tag, $compile,$target, $folder,$show_empty);
	        									}
	        								?>
			        					</li>	
			        			<?php } ?>
			        		</ul>
			        	</li>
			        <?php } ?>
			        </ul>
				        <a id="toTop" href="#top-page"><span></span></a>
			    </div>
			</div>
		</div>
		
		
		
		<script>
			jQuery(document).ready(function ($) {
			
			
				// Define the Template
				var template = '<?php echo TEMPLATE;?>';
				
				// Remove onclick behaviour in J admin
				// We add it back later
				
				$('#toolbar-apply button,#toolbar-save button').attr('onclick','').unbind('click');
				
				// Back to top link
				$(window).scroll(function () {
					
						if ($(this).scrollTop() >200) {
						 	$("#toTop").fadeIn();
						}
						else {
						 	$("#toTop").fadeOut();
						}
					});
				
					$("#toTop").click(function() {
						$("html, body").animate({ scrollTop: 0 }, "slow");
						 return false;
					});
				
				
				
				// Checkbox states
				$('#theme-settings input[type="checkbox"]').each(function () {
					
					var toggle = $(this).attr('id');
					
					$('.' + toggle).hide().parent().hide();
					
					if($(this).prop('checked') ) {	
						$('.' + toggle).fadeIn().parent().show();
					} 
				});
				
				
				
				// Select states
				$('#theme-settings .zen-select').each(function () {
					
					
					var toggle = $(this).attr('id');
					
					if($(this).val() == -1) {
						$('.' + toggle).fadeIn();
						
					}
					
					else {
						$('.' + toggle).fadeOut();
					}
				});
				
				
				// Select states
				$('#theme-settings .zen-select').change(function () {
					
					var toggle = $(this).attr('id');
					
					if($(this).val() == -1) {
						$('.' + toggle).fadeIn();
						
					}
					
					else {
						$('.' + toggle).fadeOut();
					}
				});				
				
				
				
				$('#theme-settings input[type="checkbox"]').click(function() {
					
					var toggle = $(this).attr('id');
					
					// Set value to 0
					$(this).val('');
					
					// Check if checked and set to 1
					if($(this).is(':checked')) {
						$(this).val(1);
						$('.' + toggle).fadeIn().parent().show();
					}
					else {
						$(this).val(0);
						$('.' + toggle).fadeOut().parent().hide();
						
					}
					
						
					
				});
				
				
				var template = '<?php echo TEMPLATE;?>';
				
				// Trigger the save function
				$('#toolbar-apply button,#toolbar-save button, #save-theme').click(function() {
					
					
					// Tell which button was clicked
					var clicked = $(this).parent().attr('id');
				
					
					
					
					var clean_theme = $('input#theme').val(); 
						clean_theme = clean_theme.replace('presets/theme.[example]-','');
					
					$('input#theme').val(clean_theme);
					
					var settings ="{";
	    	    		settings += "\n";
	    	    	    settings += '"params": {';
		    	    
		    	    	$('#theme-settings input,#theme-settings textarea,#theme-settings select').not('[data-compile="1"]').not('.zt-picker').not('.exclude').each(function(i) {
		    	    	
			    	    	id = $(this).attr('id');
			    	   
			    	    	if(typeof id ==="undefined") {
			    	    	
			    	    	}
			    	    	else {
			    	    		
				    	    	if($(this).is('select')) {
					    		   	value = $('select#' + id).val(); 	    	
								} else {
					    	    	
					    	    	value = $(this).val();
					    	    	
					    	    	if(value=='on') {
					    	    		value="1";
					    	    	}			    	    	
					    	    }
			    	    	
			    	    		if(i!==0) {
			    	    			settings += ',';
				    	    	}
				    	    	settings += "\n";
				    	    	settings += "\t";
				    	    	settings += '"' + id + '":';
				    	    	settings += '"' + value + '"';
					    	    
				    	    }
		    	    	});
		    	    	
		    	    	
		    	    	settings += ",\n";
		    	    	settings += "\t";
		    	    	
		    	    	// Extra Socialicons
		    	    	settings += '"socialicons": {';
		    	    	
		    	    	var count = $('#extra-social-networks li').length;
		    	    	
		    	    	$('#extra-social-networks li').each(function(i) {
		    	    		
		    	    		i = i +1;
		    	    		var link = $(this).find('input').val();	
		    	    		var icon = $(this).find('select').val();
		    	    		
		    	    		if(link !== "") {
			    	    		settings += "\n";
			    	    		settings += "\t";
			    	    		settings += "\t";
			    	    		settings += '"' + link + '": "' + icon + '"';
			    	    		
			    	    		if(i !==count) {
			    	    			settings += ',';
			    	    		}
			    	    	}
		    	    	});
		    	    	
		    	    	settings += "\n";
		    	    	settings += "\t";
		    	    	settings += "\t";
		    	    	settings += '}';		    	    
			    	    // Complete the settings group
			    	 	settings += "\n";
			    	 	settings += "\t";
			    	 	settings += "},";
			    	 	settings += "\n";
			    	 	settings += "\t";
			    	 	// Layout Settings
		    	 		settings += '"layout": {';
		    	 		settings += "\t";
				    	 	$('.module-row').each(function(i) {
				    	 		
				    	 		row = $(this).attr('data-row');
				    	 		
				    	 		if(i!==0) {
				    	 			settings += ',';
				    	 		}
				    	 		
				    	 		settings += "\n";
				    	 		settings += "\t";
				    	 		settings += "\t";
				    	 		settings += '"' + row + '": {';
				    	 		settings += "\n";
				    	 		settings += "\t\t\t";
				    	 		settings += '"positions": {';
				    	 		settings += "\n";
				    	 	
				    	 		$('#' + row +  ' div.resizable.visible').each(function(i) {
				    	 	    	
				    	 	    	
				    	 	    	id = $(this).attr('id');
				    	 	    	width = $(this).attr('data-width');
				    	 	    	
				    	 	    	if(i!==0) {
				    	 	    		settings += ',';
				    	 	    		settings += "\n";
				    	 	    	}
				
				    	 	    	settings += "\t\t\t\t";
				    	 	    	settings += '"' + id + '":';
				    	 	    	settings += '"' + width + '"';
				    	 	    	
				    	 	    });
				    	 	    settings += "\n";
				    	 	    settings += "\t\t\t";
				    	 	    settings += '},';
				    	 	    settings += "\n";
				    	 	   	settings += "\t\t\t";
				    	 	    settings += '"classes": {';
				    	 	    settings += "\n";
				    	 	    settings += "\t\t\t\t";
				    	 	    settings += '"classes":"';
				    	 		    
				    	 		    $('#' + row +  ' .stack-position a.active').each(function() {
				    	 		    	id = $(this).attr('id');
				    	 		    	settings += id + ' ';
				    	 		    });
				    	 		
				    	 		// Animation classes
				    	 		var animation = $('select#' + row + '_animation').val();
				    	 		
				    	 		if(animation !=="none" && typeof animation !=="undefined") {
				    	 			settings += " zen-animate " + animation;
				    	 		}
				    	 		
				    	 		// Row Styles classes
			    	 			var row_style = $('select#' + row + '_row_style').val();
			    	 			
			    	 			if(row_style !=="inherit" && typeof row_style !=="undefined") {
			    	 				settings += " " + row_style;
			    	 			}
				    	 		
				    	 		
				    	 		settings +=	'"';
				    	 		settings += "\n";
				    	 		settings += "\t\t\t";
				    	 		settings += '}';
				    	 		settings += "\n";
				    	 		settings += "\t\t";
				    	 		settings += '}';
				    	 	});
		    	 	
 					settings += "\n";
		    	    settings += "\t";
		    	    settings += "}";
		    	    settings += "\n";
		    	    settings += "}";
		    	    
					
					saver(settings, clicked);
				});
					
				
			
				// The Save Function
				var saver = function (content, clicked) {
	    	    
	    	    	function getUrlParameters(name) {
	    	    	    name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
	    	    	    var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
	    	    	        results = regex.exec(location.search);
	    	    	    return results == null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
	    	    	}
	    	    	
	    	    	var template_id = getUrlParameters('id');
	    	    	
	    	    	url = '../index.php?template=' + template + '&tmpl=ajax&function=ajax-save&name=config-' + template_id + '&type=config';
						
						 $.ajax({
			    	        url: url,
			    	        method: 'post',
			    	        context: document.body,
			    	        data: {
			    	        	content: content,
			    	        	admin: '1'
			    	        },
			    	        
			    	        beforeSend: function () {
			    	        
			    	        	// Success message
			    	        	jQuery('#zgfmessage').html('<div class="alert alert-success"><h4 class="alert-heading">Message</h4><p>Saving your changes.</p></div>').fadeIn();
			    	        	
			    	        	
			    	        	
			    	        	// Not compiled yet
			    	        	var compiled = 0;
			    	        	
			    	        	if($('#compile-toolbar').hasClass('uk-button-danger')) {
			    	        		
			    	        		// Safety just in case theme isnt compiled properly
			    	        		// Will show up when page reloads
			    	        		$('#compile_required').val(1);
			    	        	
			    	        		// Change state of compile button
			    	        		$('.compiler').removeClass('uk-button-danger').find('.button-title');
			    	        		
			    	        		// Compile the template
			    	        		$('body').compile_data(template);
			    	        		
			    	        		var compiled = 1;
			    	        	}
			    	           
			    	        },
			    	        success: function (data) {
			    	        
			    	        	// We need to use an inetrval here because 
			    	        	// Compile less to css might not yet be finished
			    	        	  	
			    	        	var interval = setInterval(function(){
			    	        		
			    	        		// compile required - wait
			    	        		if($('#compile_required').val()=='1') {
			    	        					
			    	        			// Do nothing
			    	        			// Wait for compile to finish
			    	        					
			    	        		}
			    	        				
			    	        		else {
			    	        				
			    	        			// Success message
			    	        			jQuery('#zgfmessage').html('<div class="alert alert-success"><h4 class="alert-heading">Message</h4><p>Your changes have been successfully saved.</p></div>').fadeIn('normal', function() {
			    	        					jQuery('#zgfmessage').delay(3000).fadeOut();
			    	        			});
			    	        							
			    	        			if(clicked == 'toolbar-save') {
			    	        					
			    	        				// Clean intrval
			    	        				clearInterval(interval);
			    	        				
			    	        				// if save and close
			    	        				Joomla.submitbutton('style.save');
			    	        						
			    	        				
			    	        						
			    	        			} else {
			    	        					
			    	        				// Clear interval
			    	        				clearInterval(interval);
			    	        				
			    	        				// if save
			    	        				Joomla.submitbutton('style.apply');
			    	        				
			    	        			}
			    	        		}
			    	        				 	
			    	        	}, 1000);
			    	        	     	
			    	        }
			    	       
			    	   	});
	    		}
	    		
	    		
	    		
	    		$('#save-layout').click(function() {
	    		
	    			
	    			settings = '{';
    			 		settings += "\t";
			    	 	$('.module-row').each(function(i) {
			    	 		
			    	 		row = $(this).attr('data-row');
			    	 		
			    	 		if(i!==0) {
			    	 			settings += ',';
			    	 		}
			    	 		
			    	 		settings += "\n";
			    	 		settings += "\t";
			    	 		settings += "\t";
			    	 		settings += '"' + row + '": {';
			    	 		settings += "\n";
			    	 		settings += "\t\t\t";
			    	 		settings += '"positions": {';
			    	 		settings += "\n";
			    	 	
			    	 		$('#' + row +  ' div.resizable.visible').each(function(i) {
			    	 	    	
			    	 	    	
			    	 	    	id = $(this).attr('id');
			    	 	    	width = $(this).attr('data-width');
			    	 	    	
			    	 	    	if(i!==0) {
			    	 	    		settings += ',';
			    	 	    		settings += "\n";
			    	 	    	}
			
			    	 	    	settings += "\t\t\t\t";
			    	 	    	settings += '"' + id + '":';
			    	 	    	settings += '"' + width + '"';
			    	 	    	
			    	 	    });
			    	 	    settings += "\n";
			    	 	    settings += "\t\t\t";
			    	 	    settings += '},';
			    	 	    settings += "\n";
			    	 	   	settings += "\t\t\t";
			    	 	    settings += '"classes": {';
			    	 	    settings += "\n";
			    	 	    settings += "\t\t\t\t";
			    	 	    settings += '"classes":"';
			    	 		    $('#' + row +  ' .stack-position a.active').each(function() {
			    	 		    	id = $(this).attr('id');
			    	 		    	settings += id + ' ';
			    	 		    });
			    	 		
			    	 		settings +=	'"';
			    	 		settings += "\n";
			    	 		settings += "\t\t\t";
			    	 		settings += '}';
			    	 		settings += "\n";
			    	 		settings += "\t\t";
			    	 		settings += '}';
			    	 	});
			 	
					settings += "\n";
    			    settings += "\t";
    			    settings += "}";
	    			    
	    			    
	    			    
	    			save_layout(settings);
	    			return false;
	    		});
	    			
	    		
	    		var save_layout = function (content) {
	    		    
	    		    var name = $('#layout-name').val();
	    		    	name = name.replace(/\s+/g, '-').toLowerCase();
	    		   	
	    		   	var name_exists = $("#layout_preset option[value='"+name+"']").length;
	    		   	
	    		   	if(name_exists < 1) {
	    		   		
		    		    // Append the new style to the select list
		    		    $('#layout_preset').append($('<option>', {
		    		        value: name,
		    		        text: name,
		    		        selected: 1
		    		    }));
	    		    
	    		    }
	    		    
	    		    url = '../index.php?template=' + template + '&tmpl=ajax&function=ajax-save&name=' + name + '&type=layouts';
	    					
					$.ajax({
		    	        url: url,
		    	        method: 'post',
		    	        context: document.body,
		    	        data: {
		    	        	content: content,
		    	        	admin: '1'
		    	        },
		    	        
		    	        beforeSend: function () {
		    	           
		    	        },
		    	        success: function (data) {
			    	        // Success message
			    	        jQuery('#zgfmessage').html('<div class="alert alert-success"><h4 class="alert-heading">Message</h4><p>New layout saved successfully.</p></div>').fadeIn('normal', function() {
			    	        		jQuery('#zgfmessage').delay(3000).fadeOut();
			    	        });  
		    	        }
		    	       
		    	   	});
    			}
	    		
	    		
	    		$( ".resizable" ).each(function() {
	    			var width = Math.round($(this).width() / 50);
	    			$(this).attr('class','').addClass('resizable ui-widget-content ui-resizable visible');
	    			$(this).find('.ui-widget-header span.col-count').text();
	    			$(this).find('.ui-widget-header span.col-count').text(width).parent().parent().addClass('grid-'+ width).attr('data-width', width);
	    			
	    			if($(this).attr('data-active')) {
	    				$(this).addClass('visible');
	    			} else {
	    				$(this).fadeOut().removeClass('visible');
	    				var id = $(this).attr('id');
	    				
	    				$('.unused-modules div[data-id="' + id + '"]').fadeIn().addClass('active').parent().addClass('active');
	    			}
	    		});
	    		
	    		
	    		$( ".resizable" ).resizable({
	    		      grid: 40,
	    		      minWidth:40,
	    		      containment: "#resize-container",
	    		      handles: 'e',
	    		      
	    		      resize: function( event, ui ) {
	    		      	$(this).attr('class','').addClass('resizable ui-widget-content ui-resizable visible');
	    		      	
	    		      	var width = Math.round($(this).width() / 50);
	    		      	$(this).find('.ui-widget-header span.col-count').text();
	    		      	$(this).find('.ui-widget-header span.col-count').text(width).parent().parent().addClass('grid-'+ width).attr('data-width', width);
	    		      	
	    		      }
	    		 });
	    		 
	    		 $('.module-row .icon-eye').live('click',function() {
	    		 	
	    		 	 var id = $(this).parent().parent().attr('id');
	    		 	
	    		 	 	$(this).parent().parent().fadeOut().removeClass('visible');
	    		 	 	$('div[data-id="' + id + '"]').fadeIn().addClass('active').parent().addClass('active');
	    		 	 	
	    		 });
	    		 
	    		 $('.unused-modules div').live('click', function() {
	    		 	
	    		 		var target = $(this).parent().attr('data-id');
	    		 		var id = $(this).attr('data-id');
	    		 		
	    		 		$('div[data-id="'+ id +'"]').removeClass('active').fadeOut();
	    		 		
	    		 		if($('.unused-modules[data-id="' + target + '"] .active').length == 0)
	    		 		{
	    		 			$(this).parent().removeClass('active');
	    		 				
	    		 		} 
	    		 		
	    		 		$('.module-row #' + id).fadeIn().addClass('visible');
	    		 		
	    		 });
	    		 
	    		 
	    		setTimeout(function() {
	    			 $('#system-message-container').fadeOut();
	    		},2000);
	    		 
	    		 
	    		// Das ist Smooth linking
	    		jQuery('.subnavlink-item').smoothScroll({
	    			offset: -160,
	    			easing: 'swing'
	    		});
	    		
	    		jQuery('.subnavlink-item').click(function() {
	    			return false;
	    		});
	    		
	    		
	    		jQuery('.stack-positions').live('click', function() {
	    			$(this).toggleClass('active');
	    			return false;
	    		});
	    		
	    		
	    		$(window).scroll(function(){
	    			var scrolled = $(window).scrollTop();
	    		      
	    		      if(scrolled > 120) { 
	    		     	 $(".subnavlinks").addClass('sticky');
	    		     } else {
	    		     	$(".subnavlinks").removeClass('sticky');
	    		     }
	    		
	    		});
	    		
	    		
	    		$('.zt-picker,[data-compile="1"],[data-compile="both"]').live('change', function() {
	    			$('.compiler .button-title').text("Please save your changes").parent().addClass('uk-button-danger');
	    		});
	    		
	    		
	    		$('#cssfile').live('change', function() {
	    			var name = $(this).val();
	    			
	    			var firstletter = name.charAt(0);
	    			
	    			if(firstletter == "p") {
	    				$('.compiler .button-title').text("Please save your changes").parent().addClass('uk-button-danger');
	    			}
	    			
	    		});
	    		
	    		
	    		$('.compress').live('change', function() {
	    			$('#compresser .button-title').text('Click to compress changes').parent().addClass('uk-button-danger');
	    		});
	
	    		
	    		
	    		var advanced_settings = $('#advanced_setting').val();
	    		
	    		if(advanced_settings =='1') {
	    			$('#framework-options').addClass('pro').removeClass('basic');
	    			$('.toggle-advanced').text('Hide Advanced Options');
	    		
	    		} else {
	    			
	    			$('#framework-options').removeClass('pro').addClass('basic');
	    			$('.toggle-advanced').text('Show Advanced Options');
	    		}
	    		
	    		
	    		
	    		$('.toggle-advanced').click(function() {
	    			
	    			var options = '#framework-options';
	    			
	    			if($(options).hasClass('basic')) {
	    				$(options).addClass('pro').removeClass('basic');
	    				$('.toggle-advanced').text('Hide Advanced Options');
	    				$('#advanced_setting').val('1');
	    			} else {
	    				$(options).removeClass('pro').addClass('basic');
	    				$('.toggle-advanced').text('Show Advanced Options');
	    				$('#advanced_setting').val('0');
	    			}
	    			return false;
	    		});
	    		
	    		
	    		
	    		var hide_value = $('input#hide_info').val();
	    		
	    		if(hide_value == 1) {
	    			$('.info,.checkbox-info,.textarea-info').hide();
	    		}
	    		else {
	    			$('.info,.checkbox-info,.textarea-info').show();
	    		}
	    		
	    		jQuery('#hide_info').live('click', function() {
	    			   			
	    			var hide_value = $('input#hide_info').val();
	    			
	    			if(hide_value == 1) {
	    				$('.info,.checkbox-info,.textarea-info').hide();
	    			}
	    			else {
	    				$('.info,.checkbox-info,.textarea-info').show();
	    			}
	    			
	    			
	    		});
	    		
	    		
	    		// Check colour pickers to see if using variables
	    		$( ".zt-picker" ).each(function() {
	    			
	    			var value = $(this).val();
	    			var firstletter = value.charAt(0);
	    			
	    			if(firstletter == "@") {
	    				var other = value.substring(1, value.length)
	    				other = $('input#' + other).val();
	  					$(this).css({'border-right-color': '#' +other});
	    			}
	    		
	    		});
	    		
	    		
	    		
	    		// Check colour pickers to see if using variables
	    		$( ".zt-picker" ).change(function() {
	    			
	    			var value = $(this).val();
	    			var firstletter = value.charAt(0);
	    			
	    			
	    			if(firstletter == "@") {
	    				var other = value.substring(1, value.length)
	    				other = $('input#' + other).val();
	    				
	    				var firstletter = other.charAt(0);
	 					
	 					if(firstletter == "@") {
	 						other = other.substring(1, value.length)
	 						other = $('input#' + other).val();
	 					}

	   					$(this).css({'border-right-color': '#' +other});
	    			}
	    		
	    		});
	    		
	    		
	    		
	    		// Check colour pickers to see if using variables
	    		$( ".zt-picker" ).each(function() {
	    			
	    			var val = $(this).val();
	    			
	    			var firstletter = val.substring(0, 3);
	    				
	    				if(firstletter == "dar" || firstletter == "lig") {
	    					
	    					
	    					if(firstletter == "dar") {
	    						var other = val.substring(8, val.length);
	    						other = other.split(',');
	    					}
	    					
	    					
	    					if(firstletter == "lig") {
	    						var other = val.substring(9, val.length);
	    						other = other.split(',');
	    					}
	    					
	    					
	    					// Change % into a decimal    				
	    					var percentage = other[1].slice(0,-2);
	    						percentage = parseFloat(percentage) / 100.0;
	    						
	    						if(firstletter == "dar") {
	    							percentage = '-' + percentage;
	    						}
	    					
	    						
	    						other = other[0];
	    						other = $('input#' + other).val();
	    						
	    						var newColor = $(document).ColorLuminance(other, percentage); 
	    						
	    						$(this).css({'border-right-color': newColor});
	    				}
	    		
	    		});
	    		
	    		
	    		$( ".zt-picker" ).change(function() {
		    		var value = $(this).val();
		    		// Grab the 3rd letter because d and a are valid hex values
		    			// da - r- ken  and li - g -hten
		    			var firstletter = value.charAt(2);
		    			
		    			if(firstletter == "r") {
		    				
		    				var other = value.substring(8, value.length);
		    		
		    					other = other.split(',');
		    			}
		    			
		    			if(firstletter == "g") {
		    				
		    				var other = value.substring(9, value.length);
		    					other = other.split(',');
		    			}
		    			
		    			
		    			if(firstletter == "r" || firstletter == "g") {
		    				
		    				// Change % into a decimal    
		    							
		    				var percentage = other[1].slice(0,-2);
		    					
		    					
		    					if(firstletter == "r") {
		    						percentage = 1 / percentage;
		    						percentage = '-' + percentage;
		    					} else {
		    						percentage = 10 / percentage;
		    					}
		    				
		    					other = other[0];
		    					other = $('input#' + other).val();
		    					
		    					
		    				var newColor = $(document).ColorLuminance(other, percentage); 
		    				 
		    				$(this).css({'border-right-color': newColor});
		    			}
	    		});
	    		
	    						
				
				
				
				// Compile button
				$('.compiler').click(function() {
					$('.compiler').removeClass('uk-button-danger').find('.button-title');
					$('body').compile_data(template);
					
				});
				
				// Create template.css file if enabled for the first time.
				$('#load_template_css').click(function() {
					var enable_template_css = $(this).val();
					
					if(enable_template_css =="1") {
						$('body').compile_data(template,enable_template_css);
					}
				});
				
				
				// Compress Button
				$('.compresser').click(function() {
					$(this).removeClass('uk-button-danger').find('.button-title').text('Compressing Scripts');
					$(document).compress_data(template);
					    	
					return false;
				});
				
				// Apply Styles from other instances
				$(document).on('click', '#apply-style', function() {
				   	$(document).apply_style(template);
				   	return false;
				});
				
				// Activate sidebar menu item
				$('#zen-sidebar li').click(function() {
					$('#active_tab').val('');
					var active_item = $(this).attr('data-id');
					$('#active_tab').val(active_item);
				});
				
				// Set the active sidebar item
				var active_item = $('#active_tab').val();
				
				if(active_item == "") {
					active_item ="overview"
				}
				
				$('#zen-sidebar li').removeClass('uk-active');
				$('#zen-sidebar li[data-id="' + active_item + '"]').addClass('uk-active');
				$('#theme-settings > li').removeClass('uk-active');
				$('#theme-settings > li#' + active_item).addClass('uk-active');
				
				
				// Delete a theme
				// Apply Styles from other instances
				$(document).on('click', '#delete-theme', function() {
				   	$(document).delete_theme(template);
				   	return false;
				});
				
				// Compile required
				if($('#compile_required').val() == "1") {
					$('.compiler .button-title').text("Please save your changes").parent().addClass('uk-button-danger');
				}
				
				// Sanitise quotation marks
				// Select states
				$('#theme-settings textarea,#theme-settings input').on('change', function () {
					
					var value = $(this).val();
						
					// replace #
					value = value.replace(/"/g, '\'');
						
					// replace new lines
					value = value.replace(/\n/g, '');
						
					$(this).val(value);
					
				});		
				
				// Destory Chosen for the framework
				if(jQuery().chosen) {
					$('#framework-options select,#template-toolbar select').chosen('destroy');			
				}
				
	    	});
	    		
		</script>
		
		<?php
		return ob_get_clean();
	}
}