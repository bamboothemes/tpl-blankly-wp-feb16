<?php
/**
 * @package		Zen Grid Framework v4, 1.4.1
 * @subpackage	Updated: February 22 2016
 * @author		Joomlabamboo http://www.joomlabamboo.com
 * @copyright 	Copyright (C) Joomlabamboo, February 22 2016
 * @license		http://www.gnu.org/licenses/gpl.html GNU General Public License version 2 or later;
 * @version		1.4.1
 * This file loads the assets required for the admin panel.
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

/**
 * Form Field class for the Joomla Framework.
 *
 * @package		ZGF4
 * @subpackage	Form
 * @since		1.6
 */

class JFormFieldScripts extends JFormField
{
	protected $type = 'Scripts';

	protected function getInput()
	{
		
		// Define template name
		if (!defined('TEMPLATE')) {
			define( 'TEMPLATE', basename(dirname(dirname(dirname(__FILE__)))));
		}
		
		// Include Zen Class
		if (!defined('TEMPLATE_PATH')) {
			define( 'TEMPLATE_PATH', JPATH_ROOT.'/templates/'.TEMPLATE.'/');
		}
		
		// Include Helpers
		include_once TEMPLATE_PATH.'/zengrid/helpers/helper.php'; 
		
		$zgf = new zen();
		// Get version number
		$zgfversion = $zgf->get_xml('zengrid/zen.xml');
		
		$document = JFactory::getDocument();
		$base = JURI::root();
		$media = $base.'templates/'.TEMPLATE.'/zengrid/admin/';
		$document->addStyleSheet($media.'css/style.css?version='.$zgfversion->version );
		$document->addStyleSheet($media.'css/colpick.css?version='.$zgfversion->version );
		$document->addScript($media.'js/lib/jquery-ui-1.8.23.custom.min.js?version='.$zgfversion->version );
		$document->addScript($media.'js/lib/uikit.min.js?version='.$zgfversion->version );
		$document->addScript($media.'js/lib/colpick.js?version='.$zgfversion->version );
		$document->addScript($media.'js/lib/smoothscroll.js?version='.$zgfversion->version );		
		$document->addScript($media.'js/zengrid/set_theme_data.js?version='.$zgfversion->version );
		$document->addScript($media.'js/zengrid/set_layout_data.js?version='.$zgfversion->version );	
		$document->addScript($media.'js/zengrid/compile_data.js?version='.$zgfversion->version );
		$document->addScript($media.'js/zengrid/compress_data.js?version='.$zgfversion->version );	
		$document->addScript($media.'js/zengrid/apply_style.js?version='.$zgfversion->version );
		$document->addScript($media.'js/zengrid/delete_theme.js?version='.$zgfversion->version );	
		$document->addScript($media.'js/zengrid/tools.js?version='.$zgfversion->version );	
		
		// Import Folder system
		jimport('joomla.filesystem.folder');
		
		// Hide the following params
		
		ob_start();
		?>
		
		
		<?php
		return ob_get_clean();
	}
}