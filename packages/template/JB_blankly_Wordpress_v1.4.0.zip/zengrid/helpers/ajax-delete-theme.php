<?php
/**
 * @package		Zen Grid Framework v4, 1.4.1
 * @subpackage	Updated: February 22 2016
 * @author		Joomlabamboo http://www.joomlabamboo.com
 * @copyright 	Copyright (C) Joomlabamboo, February 22 2016
 * @license		http://www.gnu.org/licenses/gpl.html GNU General Public License version 2 or later;
 * @version		1.4.1
 */
 
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

$jinput = JFactory::getApplication()->input;
$admin = $jinput->get('admin');

if($admin) {
	
	// Define template name
	if (!defined('TEMPLATE')) {
		define( 'TEMPLATE', basename(dirname(dirname(dirname(__FILE__)))));
	}
	
	jimport('joomla.filesystem.folder');
	jimport('joomla.filesystem.file');
	
	// Get theme name
	$theme = $jinput->get('theme');
	
	
	$path = '/templates/'.TEMPLATE.'/';
	
	JFile::delete(JPATH_ROOT.$path.'css/theme.'.$theme.'.css');
	JFile::delete(JPATH_ROOT.$path.'css/theme.'.$theme.'.php');
	JFile::delete(JPATH_ROOT.$path.'settings/themes/theme.'.$theme.'.json');
	
	echo 'The '.$theme.' theme and related assets have been deleted.';
} else {
	header("Location: ".JUri::base());
	die();
}