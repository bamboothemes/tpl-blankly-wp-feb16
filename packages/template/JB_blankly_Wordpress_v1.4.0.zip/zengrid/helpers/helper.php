<?php
/**
 * @package     Zen Grid Framework v4, 1.4.1
 * @subpackage  Updated: February 22 2016
 * @author      Joomlabamboo http://www.joomlabamboo.com
 * @copyright   Copyright (C) Joomlabamboo, February 22 2016
 * @license     http://www.gnu.org/licenses/gpl.html GNU General Public License version 2 or later;
 * @version     1.4.1
 */

// No Direct Access
defined('_JEXEC') or die();


/**
 * Defines the various classes and fields used in the config.xml 
 * Called from the admin/fields/options.php
 * 
 *
 *
 *
 */
 
 
class zen
{

		/**
	     *  Render fields specified in template config.xml
	     *
	     */
	     
	     public function __construct()
	     {


	     }

	    public function render($type,$description,$label,$options, $name,$class, $value, $tag, $compile,$target,$folder,$show_empty)
	    {
	       	$path = TEMPLATE_PATH . 'zengrid/fields/'.$type.'.php';
			
			if(file_exists($path)) {
	       		include($path);
	       	}
	    }
	    
	    
	    /**
	     *  Returns contents of xml
	     *
	     */
	     
	    public function get_xml($path) {
	    	$path = TEMPLATE_PATH.$path;
	    	return JFactory::getXML($path);
	    }
	    
	    
	    
	    /**
	     * Returns a json decoded object
	     *
	     * 
	     */
	    
	    
	    public function get_json($path) {
	    	$file = TEMPLATE_PATH .$path;
	    	$settings = Jfile::Read($file);
	    	$settings = json_decode($settings);
	    	return $settings;
	    }
	    
	        
	    
	    
	   /**
	    *  List files in a folder
	    *
	    */
	    
	   public function get_files($folder, $filter) {
		   	$folder = TEMPLATE_PATH.$folder;
		   	
		   	if(JFolder::exists($folder)) {
		   		$files = JFolder::files($folder, $filter = $filter);
		   		return $files;
		   	} else {
		   		return null;
		   	}
	   }
	   
	   
	   
	   /**
	    *  List files in Images folder
	    *
	    */
	    
	   public function get_image_dir_files() {
	   	   	$folder = JPATH_ROOT.'/images/';
	   	  
	   	   	if(JFolder::exists($folder)) {
	   	   		$files = JFolder::files($folder, '.', false, false,array('.svn', 'CVS','.DS_Store','__MACOSX','index.html'));
	   	   		return $files;
	   	   	} else {
	   	   		return null;
	   	   	}
	   }
	    

    
	    /**
	     *  Get saved settings
	     *
	     */
	     
	    public function getsettings($templateId) {
	    
	    	$settings = TEMPLATE_PATH .'settings/config/config-'.$templateId.'.json';
	    	
	    	if(file_exists($settings)) {
	    	
	    		$settings = self::get_json('settings/config/config-'.$templateId.'.json');
	    			    		
	    		// Check to see if params have become corrupted
	    		// Sometimes the details arent saved properly  		
	    		if(empty($settings->params)) {
	    			
	    			// Adds a message if params are emoty
	    			JFactory::getApplication()->enqueueMessage('Stored settings corrupt. Reverting to default settings. Please check your settings.');
	    			
	    			// Load the default params
	    			return self::get_json('settings/default-config.json');
	    			
	    		}
	    		
	    		else {
	    			return self::get_json('settings/config/config-'.$templateId.'.json');
	    		}
	    		
	    	} else {
	    		return self::get_json('settings/default-config.json');
	    	}

		}	
		
		
		public function template_id() {
			$templateId = explode('&id=', $_SERVER["REQUEST_URI"]);
			$templateId = $templateId[1];
			$templateId = explode('&', $templateId);
			$templateId = $templateId[0];
			return $templateId;
		}
		
		
		
		// Get folder list
		public function expandDirectories($base_dir) {
		      $directories = array();
		      foreach(scandir($base_dir) as $file) {
		            if($file == '.' || $file == '..') continue;
		            $dir = $base_dir.DIRECTORY_SEPARATOR.$file;
		            if(is_dir($dir)) {
		                $directories []= $dir;
		                $directories = array_merge($directories, self::expandDirectories($dir));
		            }
		      }
		      return $directories;
		}	
}