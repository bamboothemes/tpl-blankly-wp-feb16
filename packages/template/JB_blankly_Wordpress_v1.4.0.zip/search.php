<?php
/**
 * The template for displaying search results pages.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#search-result
 *
 * @package blank.ly
 */


// Dummy file to load the header which loads the framework and layout

get_header(); ?>
